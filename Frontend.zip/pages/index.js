import Navbar from '@/component/navbar/Navbar'
import Landing from '@/landingcomponent/Landing'
import React from 'react'

export default function Home() {
  return (
    <>
    <Landing/>
    </>
  )
}
