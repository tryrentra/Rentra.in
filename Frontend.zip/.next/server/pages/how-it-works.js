"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/how-it-works";
exports.ids = ["pages/how-it-works"];
exports.modules = {

/***/ "./pages/how-it-works.js":
/*!*******************************!*\
  !*** ./pages/how-it-works.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction howItWorks() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        style: {\n            padding: \"10px\"\n        },\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"How it works\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                lineNumber: 6,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"Renting on Rentra is easy!\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                lineNumber: 8,\n                columnNumber: 1\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: [\n                    \"Create an Account: Sign up for an account on Rentra and create a profile.\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 10,\n                        columnNumber: 77\n                    }, this),\n                    \"List Your Items: List the items you want to rent out, set the price and availability, and add some photos.\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 11,\n                        columnNumber: 107\n                    }, this),\n                    \"Get Requests: Receive requests from renters who are interested in renting your items.\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 12,\n                        columnNumber: 86\n                    }, this),\n                    \"Accept Requests: Review the rental request and accept it if you're comfortable with the renter's profile.\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 13,\n                        columnNumber: 106\n                    }, this),\n                    \"Meet Up: Coordinate with the renter to arrange a convenient time and place for the rental pickup.\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 14,\n                        columnNumber: 98\n                    }, this),\n                    \"Rent Out Your Item: Meet the renter in person, exchange the item for the rental fee, and you're done!\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 15,\n                        columnNumber: 102\n                    }, this),\n                    \"Return the Item: At the end of the rental period, coordinate with the renter to arrange the return of the item.\",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                        lineNumber: 16,\n                        columnNumber: 112\n                    }, this),\n                    \"That's it! Renting on Rentra is a simple and straightforward process that allows you to make money by renting out items you don't use often and save money by renting items you need occasionally.\"\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n                lineNumber: 10,\n                columnNumber: 1\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\how-it-works.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (howItWorks);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob3ctaXQtd29ya3MuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQXlCO0FBRXpCLFNBQVNDLGFBQWE7SUFDcEIscUJBQ0UsOERBQUNDO1FBQUlDLE9BQU87WUFBQ0MsU0FBUTtRQUFNOzswQkFDdkIsOERBQUNDOzBCQUFFOzs7Ozs7MEJBRVgsOERBQUNBOzBCQUFFOzs7Ozs7MEJBRUgsOERBQUNBOztvQkFBRTtrQ0FBeUUsOERBQUNDOzs7OztvQkFBSztrQ0FDd0IsOERBQUNBOzs7OztvQkFBSztrQ0FDM0IsOERBQUNBOzs7OztvQkFBSztrQ0FDYyw4REFBQ0E7Ozs7O29CQUFLO2tDQUNkLDhEQUFDQTs7Ozs7b0JBQUs7a0NBQ0YsOERBQUNBOzs7OztvQkFBSztrQ0FDSSw4REFBQ0E7Ozs7O29CQUFLOzs7Ozs7Ozs7Ozs7O0FBSXJIO0FBRUEsaUVBQWVMLFVBQVVBLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZW50cmEvLi9wYWdlcy9ob3ctaXQtd29ya3MuanM/YmVlMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcblxyXG5mdW5jdGlvbiBob3dJdFdvcmtzKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7cGFkZGluZzpcIjEwcHhcIn19PlxyXG4gICAgICAgIDxwPkhvdyBpdCB3b3JrczwvcD5cclxuXHJcbjxwPlJlbnRpbmcgb24gUmVudHJhIGlzIGVhc3khPC9wPlxyXG5cclxuPHA+Q3JlYXRlIGFuIEFjY291bnQ6IFNpZ24gdXAgZm9yIGFuIGFjY291bnQgb24gUmVudHJhIGFuZCBjcmVhdGUgYSBwcm9maWxlLjxiciAvPlxyXG5MaXN0IFlvdXIgSXRlbXM6IExpc3QgdGhlIGl0ZW1zIHlvdSB3YW50IHRvIHJlbnQgb3V0LCBzZXQgdGhlIHByaWNlIGFuZCBhdmFpbGFiaWxpdHksIGFuZCBhZGQgc29tZSBwaG90b3MuPGJyIC8+XHJcbkdldCBSZXF1ZXN0czogUmVjZWl2ZSByZXF1ZXN0cyBmcm9tIHJlbnRlcnMgd2hvIGFyZSBpbnRlcmVzdGVkIGluIHJlbnRpbmcgeW91ciBpdGVtcy48YnIgLz5cclxuQWNjZXB0IFJlcXVlc3RzOiBSZXZpZXcgdGhlIHJlbnRhbCByZXF1ZXN0IGFuZCBhY2NlcHQgaXQgaWYgeW91J3JlIGNvbWZvcnRhYmxlIHdpdGggdGhlIHJlbnRlcidzIHByb2ZpbGUuPGJyIC8+XHJcbk1lZXQgVXA6IENvb3JkaW5hdGUgd2l0aCB0aGUgcmVudGVyIHRvIGFycmFuZ2UgYSBjb252ZW5pZW50IHRpbWUgYW5kIHBsYWNlIGZvciB0aGUgcmVudGFsIHBpY2t1cC48YnIgLz5cclxuUmVudCBPdXQgWW91ciBJdGVtOiBNZWV0IHRoZSByZW50ZXIgaW4gcGVyc29uLCBleGNoYW5nZSB0aGUgaXRlbSBmb3IgdGhlIHJlbnRhbCBmZWUsIGFuZCB5b3UncmUgZG9uZSE8YnIgLz5cclxuUmV0dXJuIHRoZSBJdGVtOiBBdCB0aGUgZW5kIG9mIHRoZSByZW50YWwgcGVyaW9kLCBjb29yZGluYXRlIHdpdGggdGhlIHJlbnRlciB0byBhcnJhbmdlIHRoZSByZXR1cm4gb2YgdGhlIGl0ZW0uPGJyIC8+XHJcblRoYXQncyBpdCEgUmVudGluZyBvbiBSZW50cmEgaXMgYSBzaW1wbGUgYW5kIHN0cmFpZ2h0Zm9yd2FyZCBwcm9jZXNzIHRoYXQgYWxsb3dzIHlvdSB0byBtYWtlIG1vbmV5IGJ5IHJlbnRpbmcgb3V0IGl0ZW1zIHlvdSBkb24ndCB1c2Ugb2Z0ZW4gYW5kIHNhdmUgbW9uZXkgYnkgcmVudGluZyBpdGVtcyB5b3UgbmVlZCBvY2Nhc2lvbmFsbHkuPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBob3dJdFdvcmtzIl0sIm5hbWVzIjpbIlJlYWN0IiwiaG93SXRXb3JrcyIsImRpdiIsInN0eWxlIiwicGFkZGluZyIsInAiLCJiciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/how-it-works.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/how-it-works.js"));
module.exports = __webpack_exports__;

})();