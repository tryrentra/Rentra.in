"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/about";
exports.ids = ["pages/about"];
exports.modules = {

/***/ "./pages/about.js":
/*!************************!*\
  !*** ./pages/about.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction about() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        style: {\n            padding: \"10px\"\n        },\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"At Rentra, our mission is to make peer-to-peer renting accessible, reliable, and safe for everyone. We understand that there is a huge potential in the Indian market for a platform that allows people to rent out and borrow items from each other, and we aim to be the go-to destination for all your renting needs.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 5,\n                columnNumber: 35\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                    lineNumber: 6,\n                    columnNumber: 8\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 6,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"Our team is made up of passionate individuals who are committed to providing a seamless and enjoyable renting experience. We believe in the power of community and are dedicated to building a platform that fosters trust and promotes sustainability.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 7,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                    lineNumber: 8,\n                    columnNumber: 8\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 8,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"We take pride in offering a user-friendly platform that enables easy navigation, transparent transactions, and efficient communication between renters and borrowers. Our goal is to make renting as convenient and hassle-free as possible, and we are constantly innovating and improving to achieve that.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 9,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                    lineNumber: 10,\n                    columnNumber: 8\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 10,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"Whether you're looking to rent out your unused equipment or borrow something you need for a short period of time, Rentra has got you covered. Join our growing community of users and experience the benefits of peer-to-peer renting today.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n                lineNumber: 11,\n                columnNumber: 5\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\siddh\\\\Desktop\\\\Business\\\\Rentra\\\\Frontend\\\\pages\\\\about.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (about);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hYm91dC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBeUI7QUFFekIsU0FBU0MsUUFBUTtJQUNmLHFCQUNFLDhEQUFDQztRQUFJQyxPQUFPO1lBQUNDLFNBQVE7UUFBTTs7MEJBQUcsOERBQUNDOzBCQUFFOzs7Ozs7MEJBQ2pDLDhEQUFDQTswQkFBRSw0RUFBQ0M7Ozs7Ozs7Ozs7MEJBQ0osOERBQUNEOzBCQUFFOzs7Ozs7MEJBQ0gsOERBQUNBOzBCQUFFLDRFQUFDQzs7Ozs7Ozs7OzswQkFDSiw4REFBQ0Q7MEJBQUU7Ozs7OzswQkFDSCw4REFBQ0E7MEJBQUUsNEVBQUNDOzs7Ozs7Ozs7OzBCQUNKLDhEQUFDRDswQkFBRTs7Ozs7Ozs7Ozs7O0FBRVA7QUFFQSxpRUFBZUosS0FBS0EsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL3JlbnRyYS8uL3BhZ2VzL2Fib3V0LmpzPzBjNDAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5cclxuZnVuY3Rpb24gYWJvdXQoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3twYWRkaW5nOlwiMTBweFwifX0+PHA+QXQgUmVudHJhLCBvdXIgbWlzc2lvbiBpcyB0byBtYWtlIHBlZXItdG8tcGVlciByZW50aW5nIGFjY2Vzc2libGUsIHJlbGlhYmxlLCBhbmQgc2FmZSBmb3IgZXZlcnlvbmUuIFdlIHVuZGVyc3RhbmQgdGhhdCB0aGVyZSBpcyBhIGh1Z2UgcG90ZW50aWFsIGluIHRoZSBJbmRpYW4gbWFya2V0IGZvciBhIHBsYXRmb3JtIHRoYXQgYWxsb3dzIHBlb3BsZSB0byByZW50IG91dCBhbmQgYm9ycm93IGl0ZW1zIGZyb20gZWFjaCBvdGhlciwgYW5kIHdlIGFpbSB0byBiZSB0aGUgZ28tdG8gZGVzdGluYXRpb24gZm9yIGFsbCB5b3VyIHJlbnRpbmcgbmVlZHMuPC9wPlxyXG4gICAgPHA+PGJyLz48L3A+XHJcbiAgICA8cD5PdXIgdGVhbSBpcyBtYWRlIHVwIG9mIHBhc3Npb25hdGUgaW5kaXZpZHVhbHMgd2hvIGFyZSBjb21taXR0ZWQgdG8gcHJvdmlkaW5nIGEgc2VhbWxlc3MgYW5kIGVuam95YWJsZSByZW50aW5nIGV4cGVyaWVuY2UuIFdlIGJlbGlldmUgaW4gdGhlIHBvd2VyIG9mIGNvbW11bml0eSBhbmQgYXJlIGRlZGljYXRlZCB0byBidWlsZGluZyBhIHBsYXRmb3JtIHRoYXQgZm9zdGVycyB0cnVzdCBhbmQgcHJvbW90ZXMgc3VzdGFpbmFiaWxpdHkuPC9wPlxyXG4gICAgPHA+PGJyLz48L3A+XHJcbiAgICA8cD5XZSB0YWtlIHByaWRlIGluIG9mZmVyaW5nIGEgdXNlci1mcmllbmRseSBwbGF0Zm9ybSB0aGF0IGVuYWJsZXMgZWFzeSBuYXZpZ2F0aW9uLCB0cmFuc3BhcmVudCB0cmFuc2FjdGlvbnMsIGFuZCBlZmZpY2llbnQgY29tbXVuaWNhdGlvbiBiZXR3ZWVuIHJlbnRlcnMgYW5kIGJvcnJvd2Vycy4gT3VyIGdvYWwgaXMgdG8gbWFrZSByZW50aW5nIGFzIGNvbnZlbmllbnQgYW5kIGhhc3NsZS1mcmVlIGFzIHBvc3NpYmxlLCBhbmQgd2UgYXJlIGNvbnN0YW50bHkgaW5ub3ZhdGluZyBhbmQgaW1wcm92aW5nIHRvIGFjaGlldmUgdGhhdC48L3A+XHJcbiAgICA8cD48YnIvPjwvcD5cclxuICAgIDxwPldoZXRoZXIgeW91JmFwb3M7cmUgbG9va2luZyB0byByZW50IG91dCB5b3VyIHVudXNlZCBlcXVpcG1lbnQgb3IgYm9ycm93IHNvbWV0aGluZyB5b3UgbmVlZCBmb3IgYSBzaG9ydCBwZXJpb2Qgb2YgdGltZSwgUmVudHJhIGhhcyBnb3QgeW91IGNvdmVyZWQuIEpvaW4gb3VyIGdyb3dpbmcgY29tbXVuaXR5IG9mIHVzZXJzIGFuZCBleHBlcmllbmNlIHRoZSBiZW5lZml0cyBvZiBwZWVyLXRvLXBlZXIgcmVudGluZyB0b2RheS48L3A+PC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhYm91dCJdLCJuYW1lcyI6WyJSZWFjdCIsImFib3V0IiwiZGl2Iiwic3R5bGUiLCJwYWRkaW5nIiwicCIsImJyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/about.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/about.js"));
module.exports = __webpack_exports__;

})();